package com.example.guest_3csvcu.stovesaver;

import android.app.TimePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;

import java.io.BufferedReader;
import java.io.Console;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;


public class MainActivity extends AppCompatActivity {
    private Button dateButton;
    private Button testButton;
    private TextView dateText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dateText = (TextView)findViewById(R.id.dateText);
        dateButton = (Button)findViewById(R.id.dateButton);
        dateButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                // Use the current time as the default values for the picker
                final Calendar c = Calendar.getInstance();
                int hour = c.get(Calendar.HOUR_OF_DAY);
                int minute = c.get(Calendar.MINUTE);
                // Create a new instance of TimePickerDialog and return it
                new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener(){

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        dateText.setText("Gas Stove will be closed at " + hourOfDay + ":" + minute);
                    }
                }, hour, minute, false).show();
            }

        });
        testButton = (Button)findViewById(R.id.testButton);
        testButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                dateText.setText("Close gas stove...");
                try
                {
                    String data=postHtml("https://www.google.com/");
                    Log.d("TEST",""+data);
                }catch (Exception e) {}


            }

        });
    }
    public static String postHtml(String path) throws Exception {
        URL url = new URL(path);
        StringBuilder response  = new StringBuilder();
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setDoInput(true);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type","application; charset=UTF-8");
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(5000);

        OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
        int test=123;
        writer.write("{"+"\"test\":"+"\""+test+"\""+"}");

        writer.flush();
        writer.close();
        return null;
    }

}
